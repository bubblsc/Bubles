<h2><?= $title ?></h2>
<p>Hi, Welcome to my blog!!</p>
<p><h1 style="color:pink;">"Some day we will find what we are looking for</p></h1>
<p><h2 style="color:pink;">or maybe not</p></h2>
<p><h3 style="color:pink;">maybe we'll find something much greater than that"</p></h3>

<p><h4 style="color:yellow;">"Don't give up because you had a bad day, forgive yourself and do better"</p></h4>